<?php
require_once 'database.php';

// Generate nomor daftar otomatis
function generateNoDaftar($conn) {
    $tahun = date('Y');
    $bulan = date('m');
    
    $sql = "SELECT MAX(CAST(SUBSTRING(no_daftar, -4) AS UNSIGNED)) AS max_no 
            FROM pendaftar 
            WHERE SUBSTRING(no_daftar, 1, 6) = '$tahun$bulan'";
    
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    
    $next_no = ($row['max_no'] ?? 0) + 1;
    return $tahun . $bulan . str_pad($next_no, 4, '0', STR_PAD_LEFT);
}

// Tambah Pendaftar
function tambahPendaftar($conn, $data) {
    $no_daftar = generateNoDaftar($conn);
    $status = 'pending';
    $keterangan = '';
    
    $stmt = $conn->prepare("
        INSERT INTO pendaftar 
        (no_daftar, nama_pendaftar, tgl_lahir, jenis_kelamin, alamat, no_telepon, email, tgl_daftar, jam_daftar, status, keterangan)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->bind_param(
        "sssssssssss",
        $no_daftar,
        $data['nama_pendaftar'],
        $data['tgl_lahir'],
        $data['jenis_kelamin'],
        $data['alamat'],
        $data['no_telepon'],
        $data['email'],
        $data['tgl_daftar'],
        $data['jam_daftar'],
        $status,
        $keterangan
    );
    
    if ($stmt->execute()) {
        return ['success' => true, 'no_daftar' => $no_daftar];
    } else {
        return ['success' => false, 'error' => $stmt->error];
    }
}

// Ambil data Pendaftar
function getPendaftar($conn, $no_daftar = null) {
    if ($no_daftar) {
        $sql = "SELECT * FROM pendaftar WHERE no_daftar = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $no_daftar);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    } else {
        $sql = "SELECT * FROM pendaftar ORDER BY created_at DESC";
        return $conn->query($sql);
    }
}

// Update Status Pendaftar
function updateStatusPendaftar($conn, $no_daftar, $status, $keterangan = '') {
    $stmt = $conn->prepare("UPDATE pendaftar SET status = ?, keterangan = ? WHERE no_daftar = ?");
    $stmt->bind_param("sss", $status, $keterangan, $no_daftar);
    return $stmt->execute();
}

// Tambah Daftar Ulang
function tambahDaftarUlang($conn, $data) {
    $stmt = $conn->prepare("
        INSERT INTO daftar_ulang 
        (no_daftar, nama_pendaftar, tgl_lahir, ktp, no_ijazah, tgl_ulang, jam_ulang, status, keterangan)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    if (!$stmt) {
        return ['success' => false, 'error' => $conn->error];
    }
    
    $status = 'pending';
    $keterangan = '';
    
    $stmt->bind_param(
        "sssssssss",
        $data['no_daftar'],
        $data['nama_pendaftar'],
        $data['tgl_lahir'],
        $data['ktp'],
        $data['no_ijazah'],
        $data['tgl_ulang'],
        $data['jam_ulang'],
        $status,
        $keterangan
    );
    
    if ($stmt->execute()) {
        return ['success' => true, 'id' => $conn->insert_id];
    } else {
        return ['success' => false, 'error' => $stmt->error];
    }
}

// Ambil data Daftar Ulang
function getDaftarUlang($conn, $no_daftar = null) {
    if ($no_daftar) {
        $sql = "SELECT * FROM daftar_ulang WHERE no_daftar = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $no_daftar);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    } else {
        $sql = "SELECT * FROM daftar_ulang ORDER BY created_at DESC";
        return $conn->query($sql);
    }
}

// Tambah Pengurusan Paspor
function tambahPaspor($conn, $data) {
    $stmt = $conn->prepare("
        INSERT INTO pengurusan_paspor 
        (no_daftar, nama_pendaftar, no_paspor, tgl_terbit, tgl_berlaku, tgl_expired, status, keterangan, biaya)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    if (!$stmt) {
        return ['success' => false, 'error' => $conn->error];
    }
    
    $status = 'pending';
    $keterangan = '';
    $biaya = floatval($data['biaya'] ?? 0);
    
    $stmt->bind_param(
        "ssssssssd",
        $data['no_daftar'],
        $data['nama_pendaftar'],
        $data['no_paspor'],
        $data['tgl_terbit'],
        $data['tgl_berlaku'],
        $data['tgl_expired'],
        $status,
        $keterangan,
        $biaya
    );
    
    if ($stmt->execute()) {
        return ['success' => true, 'id' => $conn->insert_id];
    } else {
        return ['success' => false, 'error' => $stmt->error];
    }
}

// Ambil data Paspor
function getPaspor($conn, $no_daftar = null) {
    if ($no_daftar) {
        $sql = "SELECT * FROM pengurusan_paspor WHERE no_daftar = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $no_daftar);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    } else {
        $sql = "SELECT * FROM pengurusan_paspor ORDER BY created_at DESC";
        return $conn->query($sql);
    }
}

// Update Status Paspor
function updateStatusPaspor($conn, $id, $status, $keterangan = '') {
    $stmt = $conn->prepare("UPDATE pengurusan_paspor SET status = ?, keterangan = ? WHERE id = ?");
    $stmt->bind_param("ssi", $status, $keterangan, $id);
    return $stmt->execute();
}

?>
