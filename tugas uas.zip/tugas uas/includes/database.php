<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_tugas";

$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$sql = "CREATE DATABASE IF NOT EXISTS " . $dbname;
if (!$conn->query($sql)) {
    die("Error membuat database: " . $conn->error);
}

$conn->select_db($dbname);

$sql_pendaftar = "CREATE TABLE IF NOT EXISTS pendaftar (
    id INT PRIMARY KEY AUTO_INCREMENT,
    no_daftar VARCHAR(50) UNIQUE NOT NULL,
    nama_pendaftar VARCHAR(100) NOT NULL,
    tgl_lahir DATE,
    jenis_kelamin VARCHAR(20),
    alamat TEXT,
    no_telepon VARCHAR(15),
    email VARCHAR(100),
    tgl_daftar DATE,
    jam_daftar TIME,
    status ENUM('pending', 'approved', 'closed') DEFAULT 'pending',
    keterangan VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if (!$conn->query($sql_pendaftar)) {
    die("Error membuat tabel pendaftar: " . $conn->error);
}

$sql_ulang = "CREATE TABLE IF NOT EXISTS daftar_ulang (
    id INT PRIMARY KEY AUTO_INCREMENT,
    no_daftar VARCHAR(50),
    nama_pendaftar VARCHAR(100),
    tgl_lahir DATE,
    ktp VARCHAR(20),
    no_ijazah VARCHAR(50),
    tgl_ulang DATE,
    jam_ulang TIME,
    status ENUM('pending', 'approved', 'closed') DEFAULT 'pending',
    keterangan VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if (!$conn->query($sql_ulang)) {
    die("Error membuat tabel daftar_ulang: " . $conn->error);
}

$sql_paspor = "CREATE TABLE IF NOT EXISTS pengurusan_paspor (
    id INT PRIMARY KEY AUTO_INCREMENT,
    no_daftar VARCHAR(50),
    nama_pendaftar VARCHAR(100),
    no_paspor VARCHAR(20),
    tgl_terbit DATE,
    tgl_berlaku DATE,
    tgl_expired DATE,
    biaya DECIMAL(10,2),
    status ENUM('pending', 'processing', 'selesai', 'closed') DEFAULT 'pending',
    keterangan VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if (!$conn->query($sql_paspor)) {
    die("Error membuat tabel pengurusan_paspor: " . $conn->error);
}

?>
