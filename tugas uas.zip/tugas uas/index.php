﻿<?php
require_once "includes/database.php";
require_once "includes/functions.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Manajemen Pendaftaran & Paspor</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <header class="profile-header">
            <div class="profile-card">
                <div class="profile-avatar">
                    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                        <defs>
                            <linearGradient id="avatarGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
                            </linearGradient>
                        </defs>
                        <circle cx="50" cy="50" r="50" fill="url(#avatarGradient)"/>
                        <circle cx="50" cy="35" r="15" fill="white" opacity="0.9"/>
                        <path d="M30 65 Q50 55 70 65 Q70 75 50 80 Q30 75 30 65" fill="white" opacity="0.9"/>
                    </svg>
                </div>
                <div class="profile-info">
                    <h1>Ariyansyah</h1>
                    <p class="profile-role">Sistem Manajemen Pendaftaran & Paspor</p>
                </div>
            </div>
        </header>

        <div class="nav-tabs">
            <button class="nav-btn active" onclick="switchTab('pendaftar')">Input Pendaftar</button>
            <button class="nav-btn" onclick="switchTab('daftar_ulang')">Daftar Ulang</button>
            <button class="nav-btn" onclick="switchTab('paspor')">Pengurusan Paspor</button>
            <button class="nav-btn" onclick="switchTab('laporan')">Laporan</button>
        </div>

        <!-- PENDAFTAR SECTION -->
        <div id="pendaftar" class="form-section active">
            <h2>Input Data Pendaftar</h2>
            <form id="form-pendaftar" data-ajax="true" data-action="actions/add_pendaftar.php">
                <div class="form-group">
                    <label>Nama Pendaftar:</label>
                    <input type="text" name="nama_pendaftar" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Lahir:</label>
                    <input type="date" name="tgl_lahir" required>
                </div>
                <div class="form-group">
                    <label>Jenis Kelamin:</label>
                    <select name="jenis_kelamin" required>
                        <option value="">-- Pilih --</option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Alamat:</label>
                    <textarea name="alamat"></textarea>
                </div>
                <div class="form-group">
                    <label>No. Telepon:</label>
                    <input type="text" name="no_telepon" required>
                </div>
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" name="email">
                </div>
                <div class="form-group">
                    <label>Tanggal Daftar:</label>
                    <input type="date" name="tgl_daftar" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                <div class="form-group">
                    <label>Jam Daftar:</label>
                    <input type="time" name="jam_daftar" value="<?php echo date('H:i'); ?>" required>
                </div>
                <button type="submit" class="btn-save">Simpan</button>
            </form>
        </div>

        <!-- DAFTAR ULANG SECTION -->
        <div id="daftar_ulang" class="form-section">
            <h2>Daftar Ulang</h2>
            <form id="form-daftar-ulang" data-ajax="true" data-action="actions/add_daftar_ulang.php">
                <div class="form-group">
                    <label>No. Daftar:</label>
                    <input type="text" name="no_daftar" required>
                </div>
                <div class="form-group">
                    <label>Nama Pendaftar:</label>
                    <input type="text" name="nama_pendaftar" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Lahir:</label>
                    <input type="date" name="tgl_lahir" required>
                </div>
                <div class="form-group">
                    <label>No. KTP:</label>
                    <input type="text" name="ktp">
                </div>
                <div class="form-group">
                    <label>No. Ijazah:</label>
                    <input type="text" name="no_ijazah">
                </div>
                <div class="form-group">
                    <label>Tanggal Daftar Ulang:</label>
                    <input type="date" name="tgl_ulang" required>
                </div>
                <div class="form-group">
                    <label>Jam Daftar Ulang:</label>
                    <input type="time" name="jam_ulang" required>
                </div>
                <button type="submit" class="btn-save">Simpan</button>
            </form>
        </div>

        <!-- PASPOR SECTION -->
        <div id="paspor" class="form-section">
            <h2>Pengurusan Paspor</h2>
            <form id="form-paspor" data-ajax="true" data-action="actions/add_paspor.php">
                <div class="form-group">
                    <label>No. Daftar:</label>
                    <input type="text" name="no_daftar" required>
                </div>
                <div class="form-group">
                    <label>Nama Pendaftar:</label>
                    <input type="text" name="nama_pendaftar" required>
                </div>
                <div class="form-group">
                    <label>No. Paspor:</label>
                    <input type="text" name="no_paspor" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Terbit:</label>
                    <input type="date" name="tgl_terbit">
                </div>
                <div class="form-group">
                    <label>Tanggal Berlaku:</label>
                    <input type="date" name="tgl_berlaku">
                </div>
                <div class="form-group">
                    <label>Tanggal Expired:</label>
                    <input type="date" name="tgl_expired">
                </div>
                <div class="form-group">
                    <label>Biaya (Rp):</label>
                    <input type="number" name="biaya" value="0">
                </div>
                <button type="submit" class="btn-save">Simpan</button>
            </form>
        </div>

        <!-- LAPORAN SECTION -->
        <div id="laporan" class="form-section">
            <h2>📊 Laporan & Statistik</h2>
            
            <div class="stats-grid">
                <?php
                $stats_pendaftar = $conn->query("SELECT COUNT(*) as total, 
                    SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) as approved,
                    SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) as pending
                    FROM pendaftar")->fetch_assoc();
                
                $stats_ulang = $conn->query("SELECT COUNT(*) as total, 
                    SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) as approved
                    FROM daftar_ulang")->fetch_assoc();
                
                $stats_paspor = $conn->query("SELECT COUNT(*) as total, 
                    SUM(CASE WHEN status='selesai' THEN 1 ELSE 0 END) as selesai,
                    SUM(biaya) as total_biaya
                    FROM pengurusan_paspor")->fetch_assoc();
                ?>
                
                <div class="stat-card card-blue">
                    <h3>📝 Total Pendaftar</h3>
                    <div class="stat-number"><?php echo $stats_pendaftar['total'] ?? 0; ?></div>
                    <div class="stat-detail">✅ Disetujui: <strong><?php echo $stats_pendaftar['approved'] ?? 0; ?></strong></div>
                    <div class="stat-detail">⏳ Pending: <strong><?php echo $stats_pendaftar['pending'] ?? 0; ?></strong></div>
                </div>

                <div class="stat-card card-pink">
                    <h3>✅ Total Daftar Ulang</h3>
                    <div class="stat-number"><?php echo $stats_ulang['total'] ?? 0; ?></div>
                    <div class="stat-detail">✅ Disetujui: <strong><?php echo $stats_ulang['approved'] ?? 0; ?></strong></div>
                </div>

                <div class="stat-card card-cyan">
                    <h3>🛂 Total Paspor</h3>
                    <div class="stat-number"><?php echo $stats_paspor['total'] ?? 0; ?></div>
                    <div class="stat-detail">✅ Selesai: <strong><?php echo $stats_paspor['selesai'] ?? 0; ?></strong></div>
                    <div class="stat-detail">💰 Total: <strong>Rp <?php echo number_format($stats_paspor['total_biaya'] ?? 0, 0, ',', '.'); ?></strong></div>
                </div>
            </div>

            <div class="laporan-tables">
                <div class="laporan-section">
                    <h3>📋 Data Pendaftar Terakhir</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>No. Daftar</th>
                                <th>Nama</th>
                                <th>Tgl Daftar</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("SELECT * FROM pendaftar ORDER BY created_at DESC LIMIT 5");
                            if ($result && $result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>
                                        <td><strong>{$row['no_daftar']}</strong></td>
                                        <td>{$row['nama_pendaftar']}</td>
                                        <td>{$row['tgl_daftar']}</td>
                                        <td><span class='status-badge status-{$row['status']}'>" . strtoupper($row['status']) . "</span></td>
                                    </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='4' style='text-align: center; color: #999;'>Belum ada data</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

                <div class="laporan-section">
                    <h3>📋 Data Daftar Ulang Terakhir</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>No. Daftar</th>
                                <th>Nama</th>
                                <th>Tgl Ulang</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("SELECT * FROM daftar_ulang ORDER BY created_at DESC LIMIT 5");
                            if ($result && $result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>
                                        <td><strong>{$row['no_daftar']}</strong></td>
                                        <td>{$row['nama_pendaftar']}</td>
                                        <td>{$row['tgl_ulang']}</td>
                                        <td><span class='status-badge status-{$row['status']}'>" . strtoupper($row['status']) . "</span></td>
                                    </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='4' style='text-align: center; color: #999;'>Belum ada data</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

                <div class="laporan-section">
                    <h3>📋 Data Paspor Terakhir</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>No. Daftar</th>
                                <th>Nama</th>
                                <th>No. Paspor</th>
                                <th>Biaya</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("SELECT * FROM pengurusan_paspor ORDER BY created_at DESC LIMIT 5");
                            if ($result && $result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>
                                        <td><strong>{$row['no_daftar']}</strong></td>
                                        <td>{$row['nama_pendaftar']}</td>
                                        <td>{$row['no_paspor']}</td>
                                        <td>Rp " . number_format($row['biaya'] ?? 0, 0, ',', '.') . "</td>
                                        <td><span class='status-badge status-{$row['status']}'>" . strtoupper($row['status']) . "</span></td>
                                    </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='5' style='text-align: center; color: #999;'>Belum ada data</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
</body>
</html>
