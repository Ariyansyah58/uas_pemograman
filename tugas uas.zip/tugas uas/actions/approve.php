<?php
header('Content-Type: application/json');
require_once '../includes/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
    exit;
}

$id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
$table = $_POST['table'] ?? '';
$status = $_POST['status'] ?? 'approved';

if (!$id || !$table) {
    echo json_encode(['success' => false, 'message' => 'Parameter tidak lengkap']);
    exit;
}

$allowed_tables = ['pendaftar', 'daftar_ulang', 'pengurusan_paspor'];
if (!in_array($table, $allowed_tables)) {
    echo json_encode(['success' => false, 'message' => 'Tabel tidak diizinkan']);
    exit;
}

$sql = "UPDATE $table SET status = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Prepare gagal: ' . $conn->error]);
    exit;
}

$stmt->bind_param("si", $status, $id);
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Status berhasil diperbarui']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal: ' . $stmt->error]);
}
?>
