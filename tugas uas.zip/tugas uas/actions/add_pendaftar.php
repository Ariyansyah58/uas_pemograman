<?php
header('Content-Type: application/json');
require_once '../includes/database.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
    exit;
}

$data = [
    'nama_pendaftar' => $_POST['nama_pendaftar'] ?? '',
    'tgl_lahir' => $_POST['tgl_lahir'] ?? '',
    'jenis_kelamin' => $_POST['jenis_kelamin'] ?? '',
    'alamat' => $_POST['alamat'] ?? '',
    'no_telepon' => $_POST['no_telepon'] ?? '',
    'email' => $_POST['email'] ?? '',
    'tgl_daftar' => $_POST['tgl_daftar'] ?? date('Y-m-d'),
    'jam_daftar' => $_POST['jam_daftar'] ?? date('H:i:s')
];

if (empty($data['nama_pendaftar']) || empty($data['tgl_lahir']) || empty($data['jenis_kelamin']) || empty($data['no_telepon'])) {
    echo json_encode(['success' => false, 'message' => 'Data tidak lengkap']);
    exit;
}

$result = tambahPendaftar($conn, $data);

if ($result['success']) {
    echo json_encode(['success' => true, 'message' => 'Data pendaftar berhasil ditambahkan. No. Daftar: ' . $result['no_daftar']]);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal: ' . ($result['error'] ?? 'unknown')]);
}
?>
