<?php
header('Content-Type: application/json');
require_once '../includes/database.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = [
        'no_daftar' => $_POST['no_daftar'] ?? '',
        'nama_pendaftar' => $_POST['nama_pendaftar'] ?? '',
        'no_paspor' => $_POST['no_paspor'] ?? '',
        'tgl_terbit' => $_POST['tgl_terbit'] ?? '',
        'tgl_berlaku' => $_POST['tgl_berlaku'] ?? '',
        'tgl_expired' => $_POST['tgl_expired'] ?? '',
        'biaya' => $_POST['biaya'] ?? 0
    ];
    
    // Validasi data
    if (empty($data['no_daftar']) || empty($data['nama_pendaftar']) || empty($data['tgl_terbit'])) {
        echo json_encode([
            'success' => false,
            'message' => 'Data tidak lengkap. Pastikan No. Daftar, Nama, dan Tgl Terbit terisi'
        ]);
        exit;
    }
    
    $result = tambahPaspor($conn, $data);
    
    if ($result) {
        echo json_encode([
            'success' => true,
            'message' => 'Data paspor berhasil ditambahkan'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Gagal menambahkan data: ' . $conn->error
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Method tidak diizinkan'
    ]);
}
?>
