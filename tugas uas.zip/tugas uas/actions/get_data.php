<?php
header('Content-Type: application/json');
require_once '../includes/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
    exit;
}

$table = $_GET['table'] ?? '';

$allowed_tables = ['pendaftar', 'daftar_ulang', 'pengurusan_paspor'];
if (!in_array($table, $allowed_tables)) {
    echo json_encode(['success' => false, 'message' => 'Tabel tidak diizinkan']);
    exit;
}

$sql = "SELECT * FROM $table ORDER BY created_at DESC";
$result = $conn->query($sql);

if ($result) {
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode(['success' => true, 'data' => $data]);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal: ' . $conn->error]);
}
?>
