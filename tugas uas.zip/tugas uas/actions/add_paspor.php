<?php
header('Content-Type: application/json');
require_once '../includes/database.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
    exit;
}

$data = [
    'no_daftar' => $_POST['no_daftar'] ?? '',
    'nama_pendaftar' => $_POST['nama_pendaftar'] ?? '',
    'no_paspor' => $_POST['no_paspor'] ?? '',
    'tgl_terbit' => $_POST['tgl_terbit'] ?? '',
    'tgl_berlaku' => $_POST['tgl_berlaku'] ?? '',
    'tgl_expired' => $_POST['tgl_expired'] ?? '',
    'biaya' => isset($_POST['biaya']) ? floatval($_POST['biaya']) : 0
];

if (empty($data['no_daftar']) || empty($data['nama_pendaftar']) || empty($data['no_paspor'])) {
    echo json_encode(['success' => false, 'message' => 'Data tidak lengkap']);
    exit;
}

$result = tambahPaspor($conn, $data);

if ($result['success']) {
    echo json_encode(['success' => true, 'message' => 'Data paspor berhasil ditambahkan']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal: ' . ($result['error'] ?? 'unknown error')]);
}
?>
