<?php
header('Content-Type: application/json');
require_once '../includes/database.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
    exit;
}

$data = [
    'no_daftar' => $_POST['no_daftar'] ?? '',
    'nama_pendaftar' => $_POST['nama_pendaftar'] ?? '',
    'tgl_lahir' => $_POST['tgl_lahir'] ?? '',
    'ktp' => $_POST['ktp'] ?? '',
    'no_ijazah' => $_POST['no_ijazah'] ?? '',
    'tgl_ulang' => $_POST['tgl_ulang'] ?? '',
    'jam_ulang' => $_POST['jam_ulang'] ?? ''
];

if (empty($data['no_daftar']) || empty($data['nama_pendaftar']) || empty($data['tgl_lahir'])) {
    echo json_encode(['success' => false, 'message' => 'Data tidak lengkap']);
    exit;
}

$result = tambahDaftarUlang($conn, $data);

if ($result['success']) {
    echo json_encode(['success' => true, 'message' => 'Data daftar ulang berhasil ditambahkan']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal: ' . ($result['error'] ?? 'unknown error')]);
}
?>
