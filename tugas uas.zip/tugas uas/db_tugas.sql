-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2026 at 10:37 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_tugas`
--

-- --------------------------------------------------------

--
-- Table structure for table `daftar_ulang`
--

CREATE TABLE `daftar_ulang` (
  `id` int(11) NOT NULL,
  `no_daftar` varchar(50) DEFAULT NULL,
  `nama_pendaftar` varchar(100) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `ktp` varchar(20) DEFAULT NULL,
  `no_ijazah` varchar(50) DEFAULT NULL,
  `tgl_ulang` date DEFAULT NULL,
  `jam_ulang` time DEFAULT NULL,
  `status` enum('pending','approved','closed') DEFAULT 'pending',
  `keterangan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `daftar_ulang`
--

INSERT INTO `daftar_ulang` (`id`, `no_daftar`, `nama_pendaftar`, `tgl_lahir`, `ktp`, `no_ijazah`, `tgl_ulang`, `jam_ulang`, `status`, `keterangan`, `created_at`) VALUES
(1, '2026010001	', 'ariyansyah', '2004-02-07', '5757757575', '6967967', '0000-00-00', '19:07:00', 'pending', '', '2026-01-09 07:08:34');

-- --------------------------------------------------------

--
-- Table structure for table `pendaftar`
--

CREATE TABLE `pendaftar` (
  `id` int(11) NOT NULL,
  `no_daftar` varchar(50) NOT NULL,
  `nama_pendaftar` varchar(100) NOT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `jenis_kelamin` varchar(20) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `no_telepon` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `tgl_daftar` date DEFAULT NULL,
  `jam_daftar` time DEFAULT NULL,
  `status` enum('pending','approved','closed') DEFAULT 'pending',
  `keterangan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pendaftar`
--

INSERT INTO `pendaftar` (`id`, `no_daftar`, `nama_pendaftar`, `tgl_lahir`, `jenis_kelamin`, `alamat`, `no_telepon`, `email`, `tgl_daftar`, `jam_daftar`, `status`, `keterangan`, `created_at`) VALUES
(1, '2026010001', 'ariyansyah', '2004-02-07', 'Laki-laki', 'kp.cibayana', '085880048382', 'riy793039@gmail.com', '2026-01-09', '08:09:00', 'pending', '', '2026-01-09 07:10:33'),
(2, '2026010002', 'rizky febriansyah', '2008-02-06', 'Laki-laki', 'kp.cibayana', '085880048382', 'okem2702@gmail.com', '2026-01-09', '08:13:00', 'pending', '', '2026-01-09 09:33:59');

-- --------------------------------------------------------

--
-- Table structure for table `pengurusan_paspor`
--

CREATE TABLE `pengurusan_paspor` (
  `id` int(11) NOT NULL,
  `no_daftar` varchar(50) DEFAULT NULL,
  `nama_pendaftar` varchar(100) DEFAULT NULL,
  `no_paspor` varchar(20) DEFAULT NULL,
  `tgl_terbit` date DEFAULT NULL,
  `tgl_berlaku` date DEFAULT NULL,
  `tgl_expired` date DEFAULT NULL,
  `biaya` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','processing','selesai','closed') DEFAULT 'pending',
  `keterangan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengurusan_paspor`
--

INSERT INTO `pengurusan_paspor` (`id`, `no_daftar`, `nama_pendaftar`, `no_paspor`, `tgl_terbit`, `tgl_berlaku`, `tgl_expired`, `biaya`, `status`, `keterangan`, `created_at`) VALUES
(1, '2026010001	', 'ariyansyah', '10101010', '2026-01-01', '2026-10-01', '2026-10-22', 2000000.00, 'pending', '', '2026-01-09 07:09:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daftar_ulang`
--
ALTER TABLE `daftar_ulang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pendaftar`
--
ALTER TABLE `pendaftar`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `no_daftar` (`no_daftar`);

--
-- Indexes for table `pengurusan_paspor`
--
ALTER TABLE `pengurusan_paspor`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `daftar_ulang`
--
ALTER TABLE `daftar_ulang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pendaftar`
--
ALTER TABLE `pendaftar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pengurusan_paspor`
--
ALTER TABLE `pengurusan_paspor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
