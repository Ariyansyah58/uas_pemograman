﻿function switchTab(tabName) {
    const sections = document.querySelectorAll(".form-section");
    const buttons = document.querySelectorAll(".nav-btn");
    
    sections.forEach(s => s.classList.remove("active"));
    buttons.forEach(b => b.classList.remove("active"));
    
    document.getElementById(tabName).classList.add("active");
    
    // Find button that corresponds to this tab
    buttons.forEach(btn => {
        if (btn.getAttribute("onclick").includes(tabName)) {
            btn.classList.add("active");
        }
    });
}

document.querySelectorAll("form[data-ajax]").forEach(form => {
    form.addEventListener("submit", function(e) {
        e.preventDefault();
        
        const formData = new FormData(form);
        const action = form.getAttribute("data-action");
        
        fetch(action, {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Berhasil: " + data.message);
                form.reset();
                location.reload();
            } else {
                alert("Error: " + data.message);
            }
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Terjadi kesalahan: " + error);
        });
    });
});

function deleteData(id, table) {
    if (confirm("Hapus data ini?")) {
        fetch("actions/delete.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: "id=" + id + "&table=" + table
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Berhasil dihapus");
                location.reload();
            } else {
                alert("Error: " + data.message);
            }
        })
        .catch(error => console.error("Error:", error));
    }
}

function approveData(id, table) {
    if (confirm("Approve data ini?")) {
        fetch("actions/approve.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: "id=" + id + "&table=" + table + "&status=approved"
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Berhasil diapprove");
                location.reload();
            } else {
                alert("Error: " + data.message);
            }
        })
        .catch(error => console.error("Error:", error));
    }
}
